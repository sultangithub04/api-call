let salary_data = {
  0: {
    hobby: "talking javascript",
    name: "Addy Osmani",
    salary: "76340.0",
  },
  1: {
    name: "Paul Irish",
    salary: "94320.0",
    status: "married",
  },
  2: {
    name: "Pete Hunt",
    salary: "67000.0",
  },
  3: {
    name: "Pete sampras",
    salary: "105540.0",
  },
  4: {
    name: "Remy Sharp",
    salary: "82220.0",
  },
  5: {
    name: "David Beckham",
    salary: "64430.0",
    sleepHour: 4,
  },
  6: {
    favLibrary: "React",
    name: "A Random Guy",
    pizzaSlice: 5,
    salary: "36000.0",
  },
  7: {
    name: "JS Dude",
    salary: "44432",
  },
  "-JvacZOcfUEvub7mxeo-": {
    name: "Jhankar Mahbub",
    organization: "Nielsen",
    salary: "53454",
  },
  "-Jvac_s61TL9oYM5SjMR": {
    name: "Jhankar Mahbub",
    salary: "43454",
  },
  "-JvacbMTxlHCG5VaVDWg": {
    name: "Jhankar Mahbub",
    salary: "33454",
  },
  "-JviNyklLgZqk4rSB8pA": {
    name: "Jhankar Mahbub",
    salary: "23444",
  },
  "-JviO0Y_tNNMQNrdZVBR": {
    name: "Jhankar Mahbub",
    salary: "63444",
  },
  "-JviO3gXUpSdnZHtliWg": {
    name: "Jhankar Mahbub",
    salary: "53655",
  },
};
